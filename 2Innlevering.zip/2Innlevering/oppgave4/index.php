<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Oppgave 4</title>
</head>

<body>
   <?php

   // Lag en liten kalkulator som tar utgangspunkt i to tall $tall1 og $tall2. Scriptet skal regne ut differansen mellom disse tallene. Resultatet skal presenteres som en setning.
   
   // Intiger Variables 
   
   $tall1 = 33;
   $tall2 = 77;

   // find the difference
   $difference = $tall1 - $tall2;

   // Print the difference
   echo $difference;




   ?>

</body>

</html>